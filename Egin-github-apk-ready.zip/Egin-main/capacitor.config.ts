import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'kg.egin.app',
  appName: 'EGIN',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
};

export default config;
